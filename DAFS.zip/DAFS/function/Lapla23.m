function [LAll] = Lapla(X, Y, c, child)
    %Cur_Mon=intersect(Idx, child)%当前节点下孩子是少数类的
    %MonIdx=find(ismember(Y,Idx));
    if ~isempty(X)
        X_bar = zeros(c, size(X, 2));
        for i = 1:c
            indices = find(ismember(Y, child(i)));
            X_bar(i, :) = mean(X(indices, :));
        end

        L = 1-pdist2(X_bar, X_bar, 'cosine');
        LAll = L - diag(diag(L)); % 相当于把对角线 7*7 置为0. 即L0
        LAll_hat = diag(sum(LAll, 2)); % sum(LAll,2)=LAll的每行相加; diag()再放到对角线上
        LAll = LAll_hat - LAll;
    else
        LAll = zeros(c, c);
    end
end
