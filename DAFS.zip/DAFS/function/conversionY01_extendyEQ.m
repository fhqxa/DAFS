function [ output_args ,Q] = conversionY01_extendyEQ( Y, numCol ,n)
    gnd = Y;
    ClassLabel = unique(Y); %Count the number of labels
    nClass = length(ClassLabel);    
    [nSmp,~] = size(Y);
    Y = eye(nClass,nClass);
    Z = zeros(nSmp,numCol);
    Q = zeros(nSmp,1);
    for i=1:nClass
        idx = find(gnd==ClassLabel(i));
        Z(idx,1:nClass) = repmat(Y(i,1:nClass),length(idx),1);
    end    
    output_args= Z;
    C=diag(n./(Z'*Z));
    C=1+mapminmax(C',0,0.1);
    for i=1:nClass
        idx = find(gnd==ClassLabel(i));
        Q(idx) = C(i);
    end  
    Q=diag(Q);
   K=diag(Q)-1;
end