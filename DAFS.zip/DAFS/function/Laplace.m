function [LAll] = Lapla(X, Y, c, child)
    if ~isempty(X)
        X_bar = zeros(c, size(X, 2));
        for i = 1:c
            indices = find(ismember(Y, child(i)));
            X_bar(i, :) = mean(X(indices, :));
        end

        L = 1-pdist2(X_bar, X_bar, 'cosine');
        LAll = L - diag(diag(L));
        LAll_hat = diag(sum(LAll, 2)); 
        LAll = LAll_hat - LAll;
    else
        LAll = zeros(c, c);
    end
end
