clc; clear;
str1={'F194','VOCResnet50','ILSVRC65','Sun','Cifar100'};
m = length(str1);
alpha =0.1; beta=0.1;lambda =100;
method1 = 'KNN';
selectNum=0.2;
for i =1%:m
    filename = [str1{i} 'Train']; 
    load (filename);
    [X,Y]=creatSubTablezh(data_array, tree);
    %Train
    [feature,obj] = DAFS(X, Y, tree, lambda, alpha, beta,1);
    %Test feature batch
    testFile = [str1{i}, 'Test.mat'];
    load (testFile);
    [accuracyMean_KNN, accuracyStd_KNN, ~, FHMean_KNN, FHStd_KNN, F_LCAMean_KNN, F_LCAStd_KNN, ~, TIEmean_KNN, TIEStd_KNN, ~, ~,accuracy_l_KNN] = HierMainPredictionBatchmon(data_array, tree, feature, method1, selectNum);
end
