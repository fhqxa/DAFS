function [predict_label] = FS_topDownMainPredictionGL(input_data, model, tree, feature, numberSel, classifierType)
    [m, ~] = size(input_data);
    root = find(tree(:,1)==0);     
	for j = 1:m%The number of samples  
        %% �ȴ�������ʼ
        selFeature = feature{root}(1:numberSel);
        switch classifierType
            case 'KNN'
                [currentNode] = predict(model{root}, input_data(j,selFeature));
            case 'SVM'
                [currentNode] = svmpredict(input_data(j,end), input_data(j,selFeature), model{root},'-q');
%             case 'Ada'
%                 [currentNode] = predict(model{root}, input_data(j,selFeature));
            case 'RF'
                [currentNode] = predict(model{root}, input_data(j,selFeature));

        end

        %% �ݹ�����м��ֱ��Ҷ�ӽ��
        while(~ismember(currentNode,tree_LeafNodeGL(tree)))
            selFeature = feature{currentNode}(1:numberSel);
            switch classifierType
                case 'KNN'
                    [currentNode] = predict(model{currentNode}, input_data(j,selFeature));
                case 'SVM'
                    [currentNode] = svmpredict(input_data(j,end),input_data(j,selFeature), model{currentNode},'-q');
%                 case 'Ada'
%                     [currentNode] = predict(model{currentNode}, input_data(j,selFeature));
                case 'RF'
                     [currentNode] = predict(model{currentNode}, input_data(j,selFeature));
%                     end
%                     [currentNode] = predicted_label;
            end

        end
        predict_label(j) = currentNode;        
    end %%endfor    
end
