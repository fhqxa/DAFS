function [accuracyMean,accuracyStd,FH,FHMean,FHStd,F_LCAMean,F_LCAStd,TIE,TIEmean,TIEStd,accuracy_l] = FS_Kflod_TopDownMainClassifiermon(data, numFolds, tree, feature, numberSel, indices, classifierType)
    [M,N]=size(data);
    accuracy_k = zeros(1,numFolds);
    [ leafNode ] = tree_LeafNodeGL( tree );
    l_rig=zeros(1,length(leafNode));
    l_num=zeros(1,length(leafNode));

    for k = 1:numFolds
        testID = (indices == k);
        trainID = ~testID;
        test_data = data(testID,1:N-1);
        test_label = data(testID,N);
        train_data = data(trainID,:);
        mon_rig=0;
        mon_num=0;
        %% Creat sub table
        [trainDataMod, trainLabelMod] = creatSubTablezh(train_data, tree);

        %% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %% Train classifiers of all internal nodes
        numNodes = length(tree(:,1));
        for i = 1:numNodes
            if (~ismember(i, tree_LeafNode(tree)))
                trainLabel = trainLabelMod{i};
                trainData = trainDataMod{i};
                if(isempty(trainData))
                    continue;
                end
                selFeature = feature{i}(1:numberSel);    
                switch classifierType
                    case 'KNN'
                        [modelKNN{i}] = fitcknn(trainData(:,selFeature), trainLabel, 'NumNeighbors', 10);
                    case 'SVM'
                        [modelSVM{i}]  = svmtrain(trainLabel, trainData(:,selFeature), '-c 1 -t 0 -q');
                    case 'RF'
                        [modelRF{i}]= fitensemble(trainData(:,selFeature), trainLabel,'Bag',100,'tree','type','classification');
             end
            end
        end
        
        %% Prediction
        switch classifierType
            case 'KNN'
                [predict_label] = FS_topDownMainPredictionGL(test_data, modelKNN, tree, feature, numberSel, classifierType); 
            case 'SVM'
                [predict_label] = FS_topDownMainPredictionGL(test_data, modelSVM, tree, feature, numberSel, classifierType);
            case 'RF'
                [predict_label] = FS_topDownMainPredictionGL(test_data, modelRF, tree, feature, numberSel, classifierType);

        end

        %% Envaluation
        [PH(k), RH(k), FH(k)] = EvaHier_HierarchicalPrecisionAndRecallGL(test_label,predict_label',tree);
        [P_LCA(k),R_LCA(k),F_LCA(k)] = EvaHier_HierarchicalLCAPrecisionAndRecallGL(test_label,predict_label',tree);
        TIE(k) = EvaHier_TreeInducedErrorGL(test_label,predict_label',tree);
        accuracy_k(k) = EvaHier_HierarchicalAccuracyGL(test_label,predict_label', tree);%����
        for j=1:length(leafNode)
            [index,l_num1]=find(test_label==leafNode(j));
            if ~isempty(l_num1)
                l_rig1=predict_label(index)==leafNode(j);
            else
                l_num1=0;
                l_rig1=0;
            end
            l_rig(j)=l_rig(j)+sum(l_rig1);
            l_num(j)=l_num(j)+sum(l_num1);
        end   
    end
accuracy_l(1,:)=leafNode;
accuracy_l(2,:)=l_rig./l_num;
accuracyMean = mean(accuracy_k); 
accuracyStd = std(accuracy_k); 
FHMean = mean(FH); 
FHStd = std(FH);
F_LCAMean = mean(F_LCA); 
F_LCAStd = std(F_LCA);
TIEmean = mean(TIE); 
TIEStd = std(TIE);
end