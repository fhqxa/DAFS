function [accuracyMean, accuracyStd, FH, FHMean, FHStd, F_LCAMean, F_LCAStd, TIE, TIEmean, TIEStd, TestTime, numSeleted,accuracy_l] = HierMainPredictionBatchmon(data_array, tree, feature, classifierType, rate)
    [m, numFeature] = size(data_array);
     numFeature = numFeature - 1; 
    numFolds  = 10;
    
    numSeleted = round(numFeature * rate);
    rand('seed', 1);
    indices = crossvalind('Kfold', m, numFolds);
    tic;
    [accuracyMean,accuracyStd,FH,FHMean,FHStd,F_LCAMean,F_LCAStd,TIE_Temp,TIEmean_Temp,TIEStd_Temp,accuracy_l] = FS_Kflod_TopDownMainClassifiermon(data_array, numFolds, tree, feature, numSeleted, indices, classifierType);
    TestTime = toc;
   % [testSample, ~] = size(data_array);
    TIE = TIE_Temp;% ./ testSample;
    TIEmean = TIEmean_Temp;% / testSample;
    TIEStd = TIEStd_Temp; %/ testSample;
end

