function [feature_slct,obj] = DAFS(X, Y, tree, lambda, alpha, beta,flag)
%rand('seed',1);
internalNodes = tree_InternalNodes(tree);
indexRoot = tree_Root(tree);% The root of the tree
noLeafNode =[internalNodes;indexRoot];
tree_Ancestor(tree,1);
eps = 1e-8; % set your own tolerance
maxIte = 10;
for i = 1:length(noLeafNode)
    ClassLabel = unique(Y{noLeafNode(i)});
    m(noLeafNode(i)) = length(ClassLabel);
end
%maxm=max(m);
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[~,d] = size(X{indexRoot}); % get the number of features
%% initialize
for j = 1:length(noLeafNode)
    child=get_children_set(tree, noLeafNode(j));
    n=length(Y{noLeafNode(j)});
    L{noLeafNode(j)}=Laplace(X{noLeafNode(j)},Y{noLeafNode(j)},m(noLeafNode(j)),child);
    [Y{noLeafNode(j)},Q{noLeafNode(j)}]=conversionY01_extendyEQ(Y{noLeafNode(j)}, m(noLeafNode(j)),n);%extend 2 to [1 0]
    K{noLeafNode(j)}=log(n./(Y{noLeafNode(j)}'*Y{noLeafNode(j)}));
    K{noLeafNode(j)}(isinf(K{noLeafNode(j)}) == 1) = 0;
    K{noLeafNode(j)}(isnan(K{noLeafNode(j)}) == 1) = 0;
    R{noLeafNode(j)}=X{noLeafNode(j)}'*X{noLeafNode(j)};
    W{noLeafNode(j)} = ones(d, m(noLeafNode(j)))*0.5;  
    XQQX{noLeafNode(j)} = X{noLeafNode(j)}'*Q{noLeafNode(j)}'*Q{noLeafNode(j)}*X{noLeafNode(j)};
    C{noLeafNode(j)}=X{noLeafNode(j)}'*Q{noLeafNode(j)}'*Q{noLeafNode(j)}*Y{noLeafNode(j)};
end
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for i = 1:maxIte
    %% initialization
    for j = 1:length(noLeafNode) 
     D{noLeafNode(j)} = diag(0.5./max(sqrt(sum(W{noLeafNode(j)}.*W{noLeafNode(j)},2)),eps));
    end
    %% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %% Update the  nodes
      A{indexRoot}=XQQX{indexRoot} + lambda * D{indexRoot};
      B{indexRoot}=alpha*K{indexRoot}*L{indexRoot}*K{indexRoot}';
      W{indexRoot} = sylvester(A{indexRoot}, B{indexRoot}, C{indexRoot});   
    for j = 1:length(internalNodes)
        if (isempty(X{internalNodes(j)}))
            continue;
        end
        A{internalNodes(j)}=XQQX{internalNodes(j)} + lambda * D{internalNodes(j)}+beta*R{internalNodes(j)};
        B{internalNodes(j)}=alpha*K{internalNodes(j)}*L{internalNodes(j)}*K{internalNodes(j)}';%beta*R{noLeafNode(j)};
        B{internalNodes(j)}(isnan(B{internalNodes(j)}) == 1) = 0;
        W{internalNodes(j)} = sylvester(A{internalNodes(j)}, B{internalNodes(j)}, C{internalNodes(j)});   
    end
    %% Print the value of object function if flag is 1.
    if (flag ==1)
        obj(i)=norm(Q{indexRoot}*(X{indexRoot}*W{indexRoot}-Y{indexRoot}))^2+lambda*L21(W{indexRoot})+alpha*trace(W{indexRoot}*K{indexRoot}*L{indexRoot}*K{indexRoot}'*W{indexRoot}');%+beta*norm(Y{indexRoot}-F{indexRoot}*R{indexRoot})^2;
        for j = 1:length(internalNodes)
         obj(i)=obj(i)+norm(Q{internalNodes(j)}*(X{internalNodes(j)}*W{internalNodes(j)}-Y{internalNodes(j)}))^2+lambda*L21(W{internalNodes(j)})+alpha*trace(W{internalNodes(j)}*K{internalNodes(j)}*L{internalNodes(j)}*K{internalNodes(j)}'*W{internalNodes(j)}')...
           +beta*trace(R{internalNodes(j)}*W{internalNodes(j)}*W{internalNodes(j)}');% +beta*norm(Y{indexRoot}-F{indexRoot}*R{indexRoot})^2;
        end
    end
end
%obj
for i = 1: length(noLeafNode)
    W1=W{noLeafNode(i)};
    W{noLeafNode(i)} = W1(:,1:m(noLeafNode(i)));
end

clear W1;
for j = 1: length(noLeafNode)
    tempVector = sum(W{noLeafNode(j)}.^2, 2);
    [atemp, value] = sort(tempVector, 'descend'); % sort tempVecror (W) in a descend order
    clear tempVector;
    feature_slct{noLeafNode(j)} = value(1:end);
end
if (flag == 1)
    fontsize = 20;
    figure1 = figure('Color',[1 1 1]);
    axes1 = axes('Parent',figure1,'FontSize',fontsize,'FontName','Times New Roman');
    
    plot(obj,'LineWidth',4,'Color',[0 0 1]);
    xlim(axes1,[0.8 10]);
%     ylim(axes1,[16000,36000]);%Cifar
% set(gca,'yscale','log') 
     set(gca,'FontName','Times New Roman','FontSize',fontsize);
    xlabel('Iteration number');
    ylabel('Objective function value');
end
end



